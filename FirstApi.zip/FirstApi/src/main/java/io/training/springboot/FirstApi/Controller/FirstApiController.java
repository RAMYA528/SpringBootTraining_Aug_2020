package io.training.springboot.FirstApi.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import io.training.springboot.FirstApi.Service.FirstApiService;
import io.training.springboot.FirstApi.model.Employee;

@RestController
public class FirstApiController {
	
	@Autowired
	private FirstApiService firstApiService;
	
	@RequestMapping(method = RequestMethod.GET, value = "/employees")
	public List<Employee> getAllEmployees() {
		return firstApiService.getAllEmployees();
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/employees/{id}")
	public Employee getEmployee(@PathVariable String id) {
		return firstApiService.getEmployee(id);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/employees")
	public List<Employee> addEmployee(@PathVariable Employee employee){
		return firstApiService.addEmployee(employee);
	}
	
	@RequestMapping(method = RequestMethod.PUT, value = "/employees")
	public List<Employee> updateEmployee(@PathVariable Employee employee){
		return firstApiService.updateEmployee(employee);
	}
	
	@RequestMapping(method = RequestMethod.DELETE, value = "/employees/{id}")
	public List<Employee> updateEmployee(@PathVariable String id){
		return firstApiService.deleteEmployee(id);
	}
	

}
