package io.training.springboot.FirstApi.Service;

import java.util.Arrays;

import java.util.List;

import org.springframework.stereotype.Service;

import io.training.springboot.FirstApi.model.Employee;
@Service
public class FirstApiService {

	List<Employee> employees=Arrays.asList(new Employee("1234","Ramya",22), 
			new Employee("2345","Falguni",22), 
			new Employee("3456","Deetsha",22));
	
	public List<Employee> getAllEmployees(){
		return employees;
	}
	
	public Employee getEmployee(String id) {
		for(Employee employee : employees) {
			if(employee.getId().equals(id))
				return employee;
		}
		return null;
	}
	
	public List<Employee> addEmployee(Employee employee){
		employees.add(employee);
		return employees;
	}
	
	public List<Employee> updateEmployee(Employee employee){
		for(Employee emp : employees) {
			if(employee.getId().equals(emp.getId())) {
				emp=employee;
				break;
			}
		}
		return employees;
	}
	
	public List<Employee> deleteEmployee(String id){
		for(int i=0;i<employees.size();i++) {
			Employee emp=employees.get(i);
			if(emp.getId().equals(id)) {
				employees.remove(i);
			}
		}
		return employees;
	}
	
	
}
